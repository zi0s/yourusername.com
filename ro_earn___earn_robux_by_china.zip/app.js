import confetti from 'canvas-confetti';

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const loginPage = document.getElementById('login-page');
    const mainPage = document.getElementById('main-page');
    const findAccountBtn = document.getElementById('find-account-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const usernameInput = document.getElementById('roblox-username');
    const loginError = document.getElementById('login-error');

    // Login flow elements
    const loginStepsContainer = document.getElementById('login-steps-container');
    const loginStep1 = document.getElementById('login-step-1');
    const loginStep2 = document.getElementById('login-step-2');
    const loadingContainer = document.getElementById('loading-container');
    const loadingText = document.getElementById('loading-text');

    // Confirmation step elements
    const confirmationAvatar = document.getElementById('confirmation-avatar');
    const confirmationUsername = document.getElementById('confirmation-username');
    const confirmMeBtn = document.getElementById('confirm-me-btn');
    const notMeBtn = document.getElementById('not-me-btn');
    const confirmationError = document.getElementById('confirmation-error');

    const userBalanceDisplay = document.getElementById('user-balance');
    const usernameDisplay = document.getElementById('username-display');
    const userAvatarDisplay = document.getElementById('user-avatar');
    const earningsList = document.getElementById('earnings-list');

    // Withdraw Modal
    const withdrawNavBtn = document.getElementById('withdraw-nav-btn');
    const withdrawModal = document.getElementById('withdraw-modal');
    const closeWithdrawModalBtn = document.getElementById('close-withdraw-modal');
    const modalBalance = document.getElementById('modal-balance');
    const withdrawAmountInput = document.getElementById('withdraw-amount');
    const confirmWithdrawBtn = document.getElementById('confirm-withdraw-btn');
    const withdrawMessage = document.getElementById('withdraw-message');
    
    // Admin Modal
    const adminModal = document.getElementById('admin-modal');
    const closeAdminModalBtn = document.getElementById('close-admin-modal');
    const adminLoginDiv = document.getElementById('admin-login');
    const adminPanelContent = document.getElementById('admin-panel-content');
    const adminCodeInput = document.getElementById('admin-code');
    const adminLoginBtn = document.getElementById('admin-login-btn');
    const adminLoginError = document.getElementById('admin-login-error');
    const withdrawalsListDiv = document.getElementById('withdrawals-list');
    const ADMIN_CODE = 'hadi1410';

    let currentUser = null;
    let pendingUser = null; // For the confirmation step
    const userCache = new Map(); // For caching Roblox API calls

    // --- UTILITY FUNCTIONS ---
    const getStorage = (key, defaultValue) => {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : defaultValue;
    };
    const setStorage = (key, value) => {
        localStorage.setItem(key, JSON.stringify(value));
    };

    // --- VIEW MANAGEMENT ---
    const showPage = (page) => {
        document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
        page.classList.remove('hidden');
        page.classList.remove('fade-out');
        page.classList.add('fade-in');
    };
    
    const hidePage = (page) => {
        page.classList.add('fade-out');
        setTimeout(() => page.classList.add('hidden'), 500);
    }

    const showModal = (modal) => {
        modal.classList.remove('hidden');
        modal.classList.remove('fade-out');
        modal.classList.add('fade-in');
    };
    const hideModal = (modal) => {
        modal.classList.add('fade-out');
        setTimeout(() => modal.classList.add('hidden'), 500);
    };

    const showLoginStep = (step) => {
        loginStep1.classList.add('hidden');
        loginStep2.classList.add('hidden');
        loadingContainer.classList.add('hidden');
        step.classList.remove('hidden');
    }

    // --- APPLICATION LOGIC ---
    const init = () => {
        const loggedInUser = getStorage('currentUser', null);
        if (loggedInUser) {
            currentUser = loggedInUser;
            setupMainPage();
        } else {
            showPage(loginPage);
        }
        setupEventListeners();
        generateFakeEarnings();
    };

    const setupMainPage = () => {
        updateUserInfo();
        showPage(mainPage);
    };
    
    const updateUserInfo = () => {
        if (!currentUser) return;
        userBalanceDisplay.textContent = currentUser.balance.toFixed(2);
        usernameDisplay.textContent = currentUser.username;
        if(currentUser.avatarUrl) {
            userAvatarDisplay.src = currentUser.avatarUrl;
        }
    };

    const handleFindAccount = async () => {
        const username = usernameInput.value.trim();
        if (username.length < 3) {
            loginError.textContent = 'Username must be at least 3 characters.';
            return;
        }
        loginError.textContent = '';
        showLoginStep(loadingContainer);
        loadingText.textContent = 'Finding your account...';

        try {
            let userData;
            if (userCache.has(username.toLowerCase())) {
                userData = userCache.get(username.toLowerCase());
            } else {
                 // The Roblox API has CORS restrictions. We'll use a public proxy for this demo.
                const USERS_API_URL = 'https://users.roproxy.com/v1/usernames/users';
                
                // Get User ID
                const userResponse = await fetch(USERS_API_URL, {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ usernames: [username], excludeBannedUsers: false })
                });

                if (!userResponse.ok) {
                    let errorBody = 'Could not read error response body.';
                    try {
                        const errorData = await userResponse.json();
                        errorBody = JSON.stringify(errorData);
                    } catch (e) {
                         // Could not parse JSON, try as text
                        try {
                           errorBody = await userResponse.text();
                        } catch (textErr) {
                            // ignore
                        }
                    }
                    console.error('Roblox API Error Response:', { status: userResponse.status, body: errorBody });
                    throw new Error(`Error from Roblox API: Status ${userResponse.status}`);
                }
                const { data: usersData } = await userResponse.json();
                if (!usersData || usersData.length === 0 || !usersData[0].id) {
                     throw new Error('Username not found.');
                }
                const { id, name: requestedUsername } = usersData[0];

                // Get Avatar using the proxy
                const THUMBNAILS_API_URL = `https://thumbnails.roproxy.com/v1/users/avatar-headshot?userIds=${id}&size=150x150&format=Png`;
                const thumbResponse = await fetch(THUMBNAILS_API_URL);
                if (!thumbResponse.ok) {
                    console.error('Failed to fetch avatar', thumbResponse.status, await thumbResponse.text());
                    throw new Error('Could not fetch avatar.');
                }
                const { data: thumbData } = await thumbResponse.json();
                const avatarUrl = thumbData[0]?.imageUrl || 'roblox-avatar.png';
                
                userData = { id, username: requestedUsername, avatarUrl };
                userCache.set(username.toLowerCase(), userData);
            }
            
            pendingUser = userData;
            confirmationUsername.textContent = userData.username;
            confirmationAvatar.src = userData.avatarUrl;
            confirmationError.textContent = '';
            showLoginStep(loginStep2);

        } catch (error) {
            showLoginStep(loginStep1);
            loginError.textContent = error.message.includes('Username not found') ? 'Roblox user not found.' : 'An error occurred. Please try again.';
            console.error('API Error in handleFindAccount:', error);
        }
    };
    
    const handleNotMe = () => {
        pendingUser = null;
        usernameInput.value = '';
        showLoginStep(loginStep1);
    };

    const login = () => {
        if (!pendingUser) return;
        
        showLoginStep(loadingContainer);
        loadingText.textContent = 'Signing you in...';
        
        setTimeout(() => {
            const username = pendingUser.username;
            const users = getStorage('users', {});
            if (!users[username]) {
                users[username] = { username, balance: 0.00, avatarUrl: pendingUser.avatarUrl };
            }
            // Update avatar URL on every login
            users[username].avatarUrl = pendingUser.avatarUrl;
            
            currentUser = users[username];
            setStorage('users', users);
            setStorage('currentUser', currentUser);
            
            hidePage(loginPage);
            setTimeout(() => {
                showLoginStep(loginStep1); // Reset login page
                setupMainPage();
            }, 500);

        }, 2000);
    };

    const logout = () => {
        currentUser = null;
        localStorage.removeItem('currentUser');
        hidePage(mainPage);
        setTimeout(() => {
            showPage(loginPage);
            usernameInput.value = '';
        }, 500);
    };

    const censorUsername = (name) => {
        if (name.length <= 4) {
            return 'U***';
        }
        return name.slice(0, -4) + '****';
    }

    const generateFakeEarnings = () => {
        const fakeUsers = [
            'CoolDude123', 'RobloxPro', 'BuilderManFan', 'Guest1337', 'EpicGamerZ',
            'PixelMaster', 'ObbyRunnerX', 'ScripterKid', 'ModelMaker', 'ArtisticRB',
            'BloxyWinner', 'DevKing', 'StudioStar', 'GameDevPro'
        ];
        const fakeSources = ['AdGate', 'Lootably', 'Torox', 'ayeT-Studios', 'TheoremReach'];
        earningsList.innerHTML = '';
        for (let i = 0; i < 7; i++) {
            const user = fakeUsers[Math.floor(Math.random() * fakeUsers.length)];
            const censoredUser = censorUsername(user);
            const amount = (Math.random() * 20 + 5).toFixed(2);
            const source = fakeSources[Math.floor(Math.random() * fakeSources.length)];
            const li = document.createElement('li');
            li.innerHTML = `
                <img src="roblox-avatar.png" class="earning-avatar" alt="avatar">
                <div class="earning-details">
                    <div><span class="earning-user">${censoredUser}</span> earned</div>
                    <div><span class="earning-amount">+${amount}</span> from <span class="earning-source">${source}</span></div>
                </div>`;
            earningsList.appendChild(li);
        }
    };
    setInterval(generateFakeEarnings, 8000);

    const openWithdrawModal = () => {
        if (!currentUser) return;
        modalBalance.textContent = currentUser.balance.toFixed(2);
        withdrawAmountInput.value = '';
        withdrawMessage.textContent = '';
        withdrawMessage.className = 'message';
        showModal(withdrawModal);
    };

    const handleWithdraw = () => {
        const amount = parseFloat(withdrawAmountInput.value);
        if (isNaN(amount) || amount <= 0) {
            withdrawMessage.textContent = 'Please enter a valid amount.';
            withdrawMessage.className = 'message error';
            return;
        }
        if (amount < 10) {
            withdrawMessage.textContent = 'Minimum withdrawal is 10 Robux.';
            withdrawMessage.className = 'message error';
            return;
        }
        if (amount > currentUser.balance) {
            withdrawMessage.textContent = 'Insufficient balance.';
            withdrawMessage.className = 'message error';
            return;
        }

        currentUser.balance -= amount;
        const users = getStorage('users', {});
        users[currentUser.username] = currentUser;

        const withdrawals = getStorage('withdrawals', []);
        withdrawals.push({
            username: currentUser.username,
            amount,
            timestamp: new Date().toISOString(),
            id: `wd-${Date.now()}`
        });

        setStorage('users', users);
        setStorage('currentUser', currentUser);
        setStorage('withdrawals', withdrawals);

        updateUserInfo();
        withdrawMessage.textContent = 'Withdrawal request submitted!';
        withdrawMessage.className = 'message success';
        
        confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 }
        });

        setTimeout(() => {
            hideModal(withdrawModal);
        }, 2000);
    };

    const showNotification = (message) => {
        const notif = document.createElement('div');
        notif.textContent = message;
        notif.style.position = 'fixed';
        notif.style.bottom = '20px';
        notif.style.right = '20px';
        notif.style.backgroundColor = getComputedStyle(document.documentElement).getPropertyValue('--primary-color').trim();
        notif.style.color = 'white';
        notif.style.padding = '15px';
        notif.style.borderRadius = '5px';
        notif.style.zIndex = '2000';
        document.body.appendChild(notif);
        setTimeout(() => {
            notif.remove();
        }, 4000);
    };
    
    // --- ADMIN LOGIC ---
    const openAdminModal = () => {
        adminLoginDiv.classList.remove('hidden');
        adminPanelContent.classList.add('hidden');
        adminCodeInput.value = '';
        adminLoginError.textContent = '';
        showModal(adminModal);
    };

    const loginAdmin = () => {
        if (adminCodeInput.value === ADMIN_CODE) {
            adminLoginDiv.classList.add('hidden');
            adminPanelContent.classList.remove('hidden');
            renderWithdrawals();
        } else {
            adminLoginError.textContent = 'Invalid code.';
        }
    };
    
    const renderWithdrawals = () => {
        const withdrawals = getStorage('withdrawals', []);
        withdrawalsListDiv.innerHTML = '';
        if (withdrawals.length === 0) {
            withdrawalsListDiv.innerHTML = '<p class="no-requests">No pending withdrawals.</p>';
            return;
        }
        
        withdrawals.forEach(req => {
            const item = document.createElement('div');
            item.className = 'withdrawal-item';
            item.innerHTML = `
                <div class="withdrawal-info">
                    User: <strong>${req.username}</strong> | Amount: <strong>${req.amount.toFixed(2)} R$</strong>
                    <br>
                    <small>${new Date(req.timestamp).toLocaleString()}</small>
                </div>
                <button class="complete-btn" data-id="${req.id}">Complete</button>
            `;
            withdrawalsListDiv.appendChild(item);
        });
    };
    
    const completeWithdrawal = (id) => {
        let withdrawals = getStorage('withdrawals', []);
        withdrawals = withdrawals.filter(req => req.id !== id);
        setStorage('withdrawals', withdrawals);
        renderWithdrawals();
    };


    // --- EVENT LISTENERS ---
    const setupEventListeners = () => {
        findAccountBtn.addEventListener('click', handleFindAccount);
        usernameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handleFindAccount();
        });
        
        confirmMeBtn.addEventListener('click', login);
        notMeBtn.addEventListener('click', handleNotMe);
        
        logoutBtn.addEventListener('click', logout);

        // Modals
        withdrawNavBtn.addEventListener('click', openWithdrawModal);
        closeWithdrawModalBtn.addEventListener('click', () => hideModal(withdrawModal));
        confirmWithdrawBtn.addEventListener('click', handleWithdraw);
        
        closeAdminModalBtn.addEventListener('click', () => hideModal(adminModal));
        adminLoginBtn.addEventListener('click', loginAdmin);
        adminCodeInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') loginAdmin();
        });

        // Admin Keybind
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === '1') {
                e.preventDefault();
                openAdminModal();
            }
        });
        
        // Dynamic event listener for complete buttons
        withdrawalsListDiv.addEventListener('click', (e) => {
            if (e.target.classList.contains('complete-btn')) {
                const id = e.target.dataset.id;
                completeWithdrawal(id);
            }
        });
    };

    // Let's go!
    init();
});